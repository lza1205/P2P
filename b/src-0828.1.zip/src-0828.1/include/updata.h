
#ifndef __UPDATA_H_
#define __UPDATA_H_



void client_updata_init(void);



#endif


