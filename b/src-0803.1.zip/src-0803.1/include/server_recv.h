
#ifndef __SERVER_RECV_H_
#define __SERVER_RECV_H_


void init_server_sock_pthread(void);



#endif

