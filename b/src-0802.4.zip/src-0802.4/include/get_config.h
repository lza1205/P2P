
#ifndef __GET_CONFIG_H_
#define __GET_CONFIG_H_



int check_config(void);

int get_config_for_json(void);



#endif


