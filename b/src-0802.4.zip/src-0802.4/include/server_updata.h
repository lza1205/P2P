
#ifndef __SERVER_UPDATA_H_
#define __SERVER_UPDATA_H_


void server_updata_init(void);



#endif

