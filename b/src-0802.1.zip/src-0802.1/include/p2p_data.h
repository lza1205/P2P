
#ifndef __P2P_DATA_H_
#define __P2P_DATA_H_

//#include "p2p.h"

void __compages_head(struct check_head *head, unsigned int air, char *name, unsigned int passwd);
int __strcpy(char *dest, const char *src, int len);



#endif

